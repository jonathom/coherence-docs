# import rasterio
# import numpy as np
# import geopandas as gpd
# import pyroSAR

def histogram(image_file):
    from pyroSAR.snap.auxil import parse_recipe, parse_node
    """Calculates the histogram for a given (single band) image file."""

    # with rasterio.open(image_file) as src:
        # band = src.read()
    
    # hist, _ = np.histogram(band, bins=256)
    return image_file
